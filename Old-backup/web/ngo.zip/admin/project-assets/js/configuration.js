// function AddLeadSource() {

//   $("#SocialHeading").html("Add Social Media");

//   $("#social_form_action").val("add");

//   $("#modal_lead_source").modal("show");

// }



function AddUpdateWebsiteForm() {



  let myForm = document.getElementById("website_info");

  var formData = new FormData(myForm);



  $("#WebsiteInfoBtn").html("Please Wait..");

  $.ajax({

    url: "action/add_update_website_info.php",

    type: "POST",

    data: formData,

    success: function (data) {

      var response = JSON.parse(data);

      ProductAlert(response.message);

      if (response.error == false) {

        setInterval(function () {

          location.reload();

        }, 1500);

        $("#WebsiteInfoBtn").html("Add");

        $("#website_info")[0].reset();

      }

    },

    cache: false,

    contentType: false,

    processData: false,

  });

  return false;

}

function openSevayeModal() {
    $('#sevayeForm')[0].reset();
    $('#sevayeModal').modal('show');
}

function SaveSevayeData() {

    var pageurl=$("#page_url").val();
    var actionType = $('#sevayeForm_action').val(); 
    var service_name = $('#service_name').val().trim();
    var service_image = $('#service_image').val().trim();
    if (service_name === '') {
        ProductAlert('Please Enter Name');
        return;
    }
     if (actionType === 'add' && service_image === '') {
        ProductAlert('Please Select an Image');
        return;
    }

    if(pageurl=='')
    {
        ProductAlert('इस पेज का URL दें');
        return;

    }
    var formData = new FormData($('#sevayeForm')[0]);
    $.ajax({
        url: 'action/add_update_sevaye.php',
        type: 'POST',
        data: formData,
        contentType: false,
        processData: false, 
        beforeSend: function () {
            $('#sevayeBtnId').prop('disabled', true).text('Saving...');
        },
        success: function (response) {
            $('#sevayeBtnId').prop('disabled', false).text('Save');
                var res = JSON.parse(response);
                if (res.error== false) {
                    ProductAlert(res.message);
                     $('#sevayeForm')[0].reset();
                      $('#sevayeForm_action').val('add');
                      $('#sevayeForm_action_value').val('-1');
                      // $('#imagePreview').remove();
                      $('#sevayeModal').modal('hide');

                      // Reload DataTable
                      $('#hamari_sevaye').DataTable().ajax.reload();
                } else {
                    ProductAlert(res.message || 'Something went wrong');
                }
        },
        error: function () {
            $('#sevayeBtnId').prop('disabled', false).text('Save');
            ProductAlert('Error saving service');
        }
    });
}


$(document).ready(function() {
    $('#hamari_sevaye').DataTable({
        "processing": true,
        "serverSide": true,
        "ajax": {
            "url": "ajax/get_hamari_sevaye_post.php",
            "type": "POST"
        },
        "columns": [
            { "data": "id" },
            { "data": "Name" },
            { "data": "Image" },
            { "data": "Action" }
        ]
    });
});


function EditSevaye(id) {
    $.ajax({
        url: "ajax/get_single_sevaye.php",
        type: "POST",
        data: { id: id },
        dataType: "json",
        success: function (res) {
            if (!res.error) {
                $('#service_name').val(res.Name);
                $('#sevayeForm_action').val('update');
                $('#sevayeForm_action_value').val(res.ID);
                $('#page_url').val(res.PageUrl);

                // Show existing image preview
                $('#imagePreview').remove();
                if (res.Image) {
                    $('#service_image').after(`<div id="imagePreview" class="mt-2">
                        <img src="../${res.Image}" width="80" class="border rounded">
                    </div>`);
                }

                $('#sevayeModal').modal('show');
            } else {
                ProductAlert(res.message);
            }
        }
    });
}



function DeleteSevaye(id) {
    if (!confirm("Are you sure you want to delete this service?")) return;

    $.ajax({
        url: "action/delete_sevaye.php",
        type: "POST",
        data: { id: id },
        dataType: "json",
        success: function (res) {
            ProductAlert(res.message);
            if (!res.error) {
                $('#hamari_sevaye').DataTable().ajax.reload();
            }
        }
    });
}
