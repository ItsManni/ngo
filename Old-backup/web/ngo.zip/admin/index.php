<?php
header("Location: authentication/login");
exit();
?>