<!-- Project assets  -->

<script src="../project-assets/js/script.js"></script>



<script src="../theme-assets/js/jquery.min.js"></script>

<!-- BOOTSTRAP JS -->
<script src="../theme-assets/plugins/bootstrap/js/popper.min.js"></script>
<script src="../theme-assets/plugins/bootstrap/js/bootstrap.min.js"></script>


<!-- Perfect SCROLLBAR JS-->
<script src="../theme-assets/plugins/p-scroll/perfect-scrollbar.js"></script>
<script src="../theme-assets/plugins/p-scroll/pscroll.js"></script>
<script src="../theme-assets/plugins/p-scroll/pscroll-1.js"></script>

<!-- SIDE-MENU JS -->
<script src="../theme-assets/plugins/sidemenu/sidemenu.js"></script>

<!-- SIDEBAR JS -->
<script src="../theme-assets/plugins/sidebar/sidebar.js"></script>


<!-- Sticky js -->
<script src="../theme-assets/js/sticky.js"></script>

<!-- CUSTOM JS -->
<script src="../theme-assets/js/custom.js"></script>

<!-- Custom-switcher -->
<script src="../theme-assets/js/custom-swicher.js"></script>

<!-- Switcher js -->
<script src="../theme-assets/switcher/js/switcher.js"></script>   


<!-- Alertify -->

<script src="../theme-assets/plugins/alertifyjs/alertify.js"></script>

