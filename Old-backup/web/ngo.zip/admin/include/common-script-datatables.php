<!-- DATA TABLE JS-->
<script src="../theme-assets/plugins/datatable/js/jquery.dataTables.min.js"></script>
<script src="../theme-assets/plugins/datatable/js/dataTables.bootstrap5.js"></script>
<script src="../theme-assets/plugins/datatable/dataTables.responsive.min.js"></script>
<script src="../theme-assets/plugins/datatable/responsive.bootstrap5.min.js"></script>
<!-- script src="../theme-assets/js/table-data.js"></script -->


