


<!-- Project assets  -->

<script src="../project-assets/js/script.js"></script>



<script src="../theme-assets/js/jquery.min.js"></script>

<!-- BOOTSTRAP JS -->
<script src="../theme-assets/plugins/bootstrap/js/popper.min.js"></script>
<script src="../theme-assets/plugins/bootstrap/js/bootstrap.min.js"></script>

<!-- INPUT MASK JS-->
<script src="../theme-assets/plugins/input-mask/jquery.mask.min.js"></script>

<!-- TypeHead js -->
<script src="../theme-assets/plugins/bootstrap5-typehead/autocomplete.js"></script>
<script src="../theme-assets/js/typehead.js"></script>

<!-- INTERNAL SELECT2 JS -->
<script src="../theme-assets/plugins/select2/select2.full.min.js"></script>

<!-- DATA TABLE JS-->
<script src="../theme-assets/plugins/datatable/js/jquery.dataTables.min.js"></script>
<script src="../theme-assets/plugins/datatable/js/dataTables.bootstrap5.js"></script>
<script src="../theme-assets/plugins/datatable/js/dataTables.buttons.min.js"></script>
<script src="../theme-assets/plugins/datatable/js/buttons.bootstrap5.min.js"></script>
<script src="../theme-assets/plugins/datatable/js/jszip.min.js"></script>
<script src="../theme-assets/plugins/datatable/pdfmake/pdfmake.min.js"></script>
<script src="../theme-assets/plugins/datatable/pdfmake/vfs_fonts.js"></script>
<script src="../theme-assets/plugins/datatable/js/buttons.html5.min.js"></script>
<script src="../theme-assets/plugins/datatable/js/buttons.print.min.js"></script>
<script src="../theme-assets/plugins/datatable/js/buttons.colVis.min.js"></script>
<script src="../theme-assets/plugins/datatable/dataTables.responsive.min.js"></script>
<script src="../theme-assets/plugins/datatable/responsive.bootstrap5.min.js"></script>
<!-- script src="../theme-assets/js/table-data.js"></script -->

<!-- Perfect SCROLLBAR JS-->
<script src="../theme-assets/plugins/p-scroll/perfect-scrollbar.js"></script>
<script src="../theme-assets/plugins/p-scroll/pscroll.js"></script>
<script src="../theme-assets/plugins/p-scroll/pscroll-1.js"></script>

<!-- SIDE-MENU JS -->
<script src="../theme-assets/plugins/sidemenu/sidemenu.js"></script>

<!-- SIDEBAR JS -->
<script src="../theme-assets/plugins/sidebar/sidebar.js"></script>

<!-- Color Theme js -->
<script src="../theme-assets/js/themeColors.js"></script>

<!-- Sticky js -->
<script src="../theme-assets/js/sticky.js"></script>

<!-- CUSTOM JS -->
<script src="../theme-assets/js/custom.js"></script>

<!-- Custom-switcher -->
<script src="../theme-assets/js/custom-swicher.js"></script>

<!-- Switcher js -->
<script src="../theme-assets/switcher/js/switcher.js"></script>   

 <!-- MULTI SELECT JS-->
<script src="../theme-assets/plugins/multipleselect/multiple-select.js"></script>
<script src="../theme-assets/plugins/multipleselect/multi-select.js"></script>

<!-- Alertify -->

<script src="../theme-assets/plugins/alertifyjs/alertify.js"></script>

<!-- SELECT2 JS -->
<script src="../theme-assets/plugins/select2/select2.full.min.js"></script>
<script src="../theme-assets/js/select2.js"></script>