$( function() {
	$('.counter').countUp();
});